#' @title pIe
#' @description To to judge if the point inside the confidence ellipsoid in 3D scatter plot.
#' @param point The new point to be judged should be imported as data frame.
#' @param xyz The points which have been grouped should be imported as data frame.
#' @param rate1 The confidence rate of PC1 should be between 0 to 1.
#' @param rate2 The confidence rate of PC2 should be between 0 to 1.
#' @param rate3 The confidence rate of PC3 should be between 0 to 1.
#' @return true of false
#' @export
point_inside_ellipse <- function(point, xyz,rate){
  # the second pca for ellipsoid transposition
  pca_point_2 <- prcomp(xyz)
  # the third pca for the solution of the axis length and the center
  pca_point_3 <- prcomp(pca_point_2$x)
  #the axis length
  variances <- summary(pca_point_3)$importance[2,]
  #the new point
  new_point_2<- as.data.frame(predict(pca_point_2,point))
  MD2<-0
  n<-ncol(xyz)
  for (i in 1:n) {
    x.point.i<- as.numeric(new_point_2[i])
    a.i <- qchisq(rate, 3) * sqrt(variances[i])
    x.center.i<- as.numeric(pca_point_3$center[i])
    dx.i<-x.point.i-x.center.i
    MD2.i<-dx.i*dx.i/(a.i*a.i)
    MD2<-MD2+MD2.i
  }
  dM<-sqrt(MD2)
  dM
}
